package com.mycompany.javaproject;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;



public class PrimaryController implements Initializable 
{
    @FXML
    private ComboBox<?> comboBox;
    @FXML
    private Button bSave;
    @FXML
    private Button bDelete;
    @FXML
    private Button bUpdate;
    @FXML
    private Button bReset;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
          private  Connection con;
          private Statement stm;
          private ResultSet rs;
       
        String DB_URL = "jdbc:mysql://localhost:3306/java_test";
        String DB_USER = "Sharmin";
        String DB_PASSWD = "abcdxyz";
           
        try
        {
            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWD);
            stm = con.createStatement();
        }
        catch(SQLException err)
        {
            status.setText("Problem : " + err);
        }
    }  


    }    
    
    @FXML
    private void doSave(ActionEvent event) 
    {
        
    }

    @FXML
    private void doDelete(ActionEvent event) 
    {
        
    }

    @FXML
    private void doUpdate(ActionEvent event) 
    {
        
    }

    @FXML
    private void doReset(ActionEvent event)
    {
        
    }


   
}
